package com.example.climbingteam.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.example.climbingteam.ui.Styles.color_main

object Mods {
    val fillMax=Modifier.fillMaxSize()
    val backMain=Modifier.background(color_main)


}